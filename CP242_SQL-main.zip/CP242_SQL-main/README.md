# CP242_SQL: ADMISSION STATISTICS

Presentation: https://www.canva.com/design/DAF9O95lOgo/I6doRNybWLBSJYnPZHkONA/edit?utm_content=DAF9O95lOgo&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton

![Logical_G17_132_421_424](https://github.com/Siripassornbibi/CP242_SQL/assets/62330969/7ef792c5-357a-4217-b145-1baa3bcf38b9)
![Relational_G17_132_421_424](https://github.com/Siripassornbibi/CP242_SQL/assets/62330969/4fe23e15-ff78-47e8-b915-66382f14a4c1)
